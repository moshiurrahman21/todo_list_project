package com.taqwa.todaylistforyou;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private FloatingActionButton fab;
    private RecyclerView recyclerView;
    private TaskAdapter taskAdapter;
    private List<Task> taskList = new ArrayList<>();

    private String taskDate = "";
    private String taskTime = "";

    private MediaPlayer deleteSound;
    private MediaPlayer completeSound;
    private MediaPlayer sendSound;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fab = findViewById(R.id.fab);
        recyclerView = findViewById(R.id.recycler_view_tasks);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        taskAdapter = new TaskAdapter(taskList);
        recyclerView.setAdapter(taskAdapter);




        fab.setOnClickListener(view -> openAddTaskDialog());

        displayTasks();

        deleteSound = MediaPlayer.create(this, R.raw.delete_sound);
        completeSound = MediaPlayer.create(this, R.raw.completed_sound);

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                Task task = taskList.get(position);
                if (direction == ItemTouchHelper.LEFT) {
                    deleteTask(position);
                } else if (direction == ItemTouchHelper.RIGHT) {
                    markTaskComplete(position);
                }
            }

            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onChildDraw(Canvas c, RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
                if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE) {
                    View itemView = viewHolder.itemView;
                    Paint paint = new Paint();

                    if (dX > 0) { // Swiping right
                        paint.setColor(Color.GREEN);
                        RectF background = new RectF(itemView.getLeft(), itemView.getTop(), dX, itemView.getBottom());
                        c.drawRect(background, paint);
                        // Add a check mark or other indicator
                    } else if (dX < 0) { // Swiping left
                        paint.setColor(Color.RED);
                        RectF background = new RectF(itemView.getRight() + dX, itemView.getTop(), itemView.getRight(), itemView.getBottom());
                        c.drawRect(background, paint);
                        // Add a delete icon or other indicator
                    }

                    super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
                }
            }
        });

        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

    private void openAddTaskDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_add_task, null);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setView(dialogView);
        AlertDialog dialog = dialogBuilder.create();

        EditText etTaskTitle = dialogView.findViewById(R.id.et_task_title);
        EditText etTaskDescription = dialogView.findViewById(R.id.et_task_description);
        Spinner spinnerCategory = dialogView.findViewById(R.id.spinner_category);
        ImageView btnSaveTask = dialogView.findViewById(R.id.btn_save_task);

        ImageView ivAddDescription = dialogView.findViewById(R.id.iv_add_description);
        ImageView ivSetAlarm = dialogView.findViewById(R.id.iv_set_alarm);

        String[] categories = {"Personal", "Work", "Shopping", "Study","Others"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        ivAddDescription.setOnClickListener(view -> {
            if (etTaskDescription.getVisibility() == View.GONE) {
                etTaskDescription.setVisibility(View.VISIBLE);
                ivAddDescription.setImageResource(R.drawable.ic_remove);
            } else {
                etTaskDescription.setVisibility(View.GONE);
                ivAddDescription.setImageResource(R.drawable.ic_add);
            }
        });

        ivSetAlarm.setOnClickListener(view -> showDateTimePicker());

        btnSaveTask.setOnClickListener(view -> {
            String taskTitle = etTaskTitle.getText().toString().trim();
            String taskDescription = etTaskDescription.getText().toString().trim();
            String selectedCategory = spinnerCategory.getSelectedItem().toString();

            sendSound = MediaPlayer.create(this, R.raw.send_sound);
            sendSound.start();

            if (taskTitle.isEmpty()) {
                Toast.makeText(this, "দয়া করে টাস্কের শিরোনাম দিন", Toast.LENGTH_SHORT).show();
            } else {
                // Use current date and time if no alarm is set
                String taskDate = this.taskDate.isEmpty() ? getCurrentDate() : this.taskDate;
                String taskTime = this.taskTime.isEmpty() ? getCurrentTime() : this.taskTime;

                saveTask(taskTitle, taskDescription, selectedCategory, taskDate, taskTime);

                // Reset the date and time for the next task
                this.taskDate = "";
                this.taskTime = "";

                displayTasks();
                dialog.dismiss();
            }
        });

        dialog.show();
    }
    private void showDateTimePicker() {
        final Calendar calendar = Calendar.getInstance();

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, month);
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

            TimePickerDialog timePickerDialog = new TimePickerDialog(this, (view1, hourOfDay, minute) -> {
                calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                calendar.set(Calendar.MINUTE, minute);
                this.taskDate = year + "-" + (month + 1) + "-" + dayOfMonth;
                this.taskTime = convertTo12HourFormat(hourOfDay, minute);
                Toast.makeText(this, "Alarm set for: " + taskDate + " " + taskTime, Toast.LENGTH_SHORT).show();
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false);

            timePickerDialog.show();
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));

        datePickerDialog.show();
    }
    private String convertTo12HourFormat(int hourOfDay, int minute) {
        boolean isPM = hourOfDay >= 12;
        int hour = hourOfDay % 12;
        if (hour == 0) {
            hour = 12; // Midnight case
        }
        String amPm = isPM ? "PM" : "AM";
        return String.format("%02d:%02d %s", hour, minute, amPm);
    }

    private void saveTask(String title, String description, String category, String date, String time) {
        SharedPreferences sharedPreferences = getSharedPreferences("TASKS", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        int taskCount = sharedPreferences.getInt("TASK_COUNT", 0);
        editor.putString("TASK_" + taskCount, title + ";" + description + ";" + category + ";" + date + ";" + time);
        editor.putInt("TASK_COUNT", taskCount + 1);
        editor.apply();
    }

    private void displayTasks() {
        taskList.clear();
        SharedPreferences sharedPreferences = getSharedPreferences("TASKS", MODE_PRIVATE);
        int taskCount = sharedPreferences.getInt("TASK_COUNT", 0);

        for (int i = taskCount - 1; i >= 0; i--) {
            String task = sharedPreferences.getString("TASK_" + i, null);
            if (task != null) {
                String[] taskDetails = task.split(";");

                String title = (taskDetails.length > 0) ? taskDetails[0] : "";
                String description = (taskDetails.length > 1) ? taskDetails[1] : "";
                String category = (taskDetails.length > 2) ? taskDetails[2] : "";
                String date = (taskDetails.length > 3) ? taskDetails[3] : "No date set";
                String time = (taskDetails.length > 4) ? taskDetails[4] : "No time set";

                taskList.add(new Task(title, description, category, date, time));
            }
        }

        taskAdapter.notifyDataSetChanged();
    }

    private void deleteTask(int position) {
        SharedPreferences sharedPreferences = getSharedPreferences("TASKS", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        int taskCount = sharedPreferences.getInt("TASK_COUNT", 0);

        for (int i = position; i < taskCount - 1; i++) {
            String task = sharedPreferences.getString("TASK_" + (i + 1), null);
            if (task != null) {
                editor.putString("TASK_" + i, task);
            }
        }

        editor.remove("TASK_" + (taskCount - 1));
        editor.putInt("TASK_COUNT", taskCount - 1);
        editor.apply();

        taskList.remove(position);
        taskAdapter.notifyItemRemoved(position);
        deleteSound.start();
    }

    private void markTaskComplete(int position) {
        Task task = taskList.get(position);
        task.setCompleted(true);
        taskAdapter.notifyItemChanged(position);
        completeSound.start();
    }

    private String getCurrentDate() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        return year + "-" + month + "-" + day;
    }

    private String getCurrentTime() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        return convertTo12HourFormat(hour, minute);
    }

}
