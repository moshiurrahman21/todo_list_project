
package com.taqwa.todaylistforyou;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        // টোস্ট মেসেজ দেখান
        Toast.makeText(context, "Alarm triggered!", Toast.LENGTH_SHORT).show();

        // নোটিফিকেশন সিস্টেম সেটআপ
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        String channelId = "task_notifications";

        // Android Oreo এবং পরবর্তীতে নোটিফিকেশন চ্যানেল তৈরি করুন
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, "Task Notifications", NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(channel);
        }

        // নোটিফিকেশন কনফিগার করুন
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_alarm)
                .setContentTitle("Task Alarm")
                .setContentText("Your task's alarm has been triggered!")
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        // নোটিফিকেশন দেখান
        notificationManager.notify(1, builder.build());
    }
}