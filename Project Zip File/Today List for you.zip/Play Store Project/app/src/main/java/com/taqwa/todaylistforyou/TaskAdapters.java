package com.taqwa.todaylistforyou;

import android.widget.Filter;

public interface TaskAdapters {
    // Implement the Filterable interface
    Filter getFilter();
}
