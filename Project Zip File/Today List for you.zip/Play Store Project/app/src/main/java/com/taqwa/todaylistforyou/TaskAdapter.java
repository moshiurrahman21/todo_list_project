package com.taqwa.todaylistforyou;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

    private List<Task> taskList;
    private Context context;
    private OnItemClickListener listener;

    // এই ইন্টারফেসটি ক্লিক ইভেন্টের জন্য
    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    // ক্লিক লিসেনার সেট করার জন্য এই মেথডটি ব্যবহার করবো
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    // Constructor
    public TaskAdapter(List<Task> tasks) {
        this.taskList = tasks;
    }

    public static class TaskViewHolder extends RecyclerView.ViewHolder {
        public TextView taskTitle;
        public TextView taskDescription;
        public TextView taskCategory; // Added for category
        public TextView taskDate; // Added for date
        public TextView taskTime; // Added for time

        public TaskViewHolder(View itemView, final OnItemClickListener listener) {
            super(itemView);
            taskTitle = itemView.findViewById(R.id.task_title);
            taskDescription = itemView.findViewById(R.id.task_description);
            taskCategory = itemView.findViewById(R.id.task_category); // Initialize category TextView
            taskDate = itemView.findViewById(R.id.task_date); // Initialize date TextView
            taskTime =
                    itemView.findViewById(R.id.task_time); // Initialize time TextView

            // ক্লিক ইভেন্ট
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position); // ক্লিক ইভেন্ট ট্রিগার করবে
                        }
                    }
                }
            });
        }
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_task, parent, false);
        return new TaskViewHolder(itemView, listener); // Pass listener to the ViewHolder
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = taskList.get(position);
        holder.taskTitle.setText(task.getTitle());
        holder.taskDescription.setText(task.getDescription());
        holder.taskCategory.setText(task.getCategory()); // Set category text
        holder.taskDate.setText(task.getDate()); // Set date text
        holder.taskTime.setText(task.getTime()); // Set time text
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }

}
